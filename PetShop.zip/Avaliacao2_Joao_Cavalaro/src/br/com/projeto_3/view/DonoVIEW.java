package br.com.projeto_3.view;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import br.com.projeto_3.dto.DonoDTO;
import br.com.projeto_3.ctr.DonoCTR;
import java.text.SimpleDateFormat;

public class DonoVIEW extends javax.swing.JInternalFrame {
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    DonoDTO donoDTO = new DonoDTO();
    DonoCTR donoCTR = new DonoCTR();
    
    int gravar_alterar;
    
    ResultSet rs;
    
    DefaultTableModel modelo_jtl_consultar_dono;
    
    public DonoVIEW() {
        initComponents();
        
        liberaCampos(false);
        
        liberaBotoes(true, false, false, false, true);
        
        modelo_jtl_consultar_dono = (DefaultTableModel) jtl_consultar_dono.getModel();
    }
    
    public void setPosicao() {
        Dimension d = this.getDesktopPane().getSize();
        this.setLocation((d.width - this.getSize().width) / 2, (d.height - this.getSize().height) / 2);
    } 
    
    private void gravar(){ 
        try{
            donoDTO.setNome_dono(nome_dono.getText());
            donoDTO.setCpf_dono(cpf_dono.getText());
            donoDTO.setSexo_dono(sexo_dono.getSelectedItem().toString());
            donoDTO.setNasc_dono(data_format.parse(nasc_dono.getText()));
            donoDTO.setTel_dono(tel_dono.getText());
            donoDTO.setRua_dono(rua_dono.getText());
            donoDTO.setBairro_dono(bairro_dono.getText());
            donoDTO.setCep_dono(cep_dono.getText());
            donoDTO.setCidade_dono(cidade_dono.getText());
            donoDTO.setEstado_dono(estado_dono.getSelectedItem().toString());
            
            JOptionPane.showMessageDialog(null, donoCTR.inserirDono(donoDTO));
        }
        catch(Exception e) {
            System.out.println("Erro ao gravar os dados" + e.getMessage());
        }
    }
    
    private void alterar(){ 
        try{
            donoDTO.setNome_dono(nome_dono.getText());
            donoDTO.setCpf_dono(cpf_dono.getText());
            donoDTO.setSexo_dono(sexo_dono.getSelectedItem().toString());
            donoDTO.setNasc_dono(data_format.parse(nasc_dono.getText()));
            donoDTO.setTel_dono(tel_dono.getText());
            donoDTO.setRua_dono(rua_dono.getText());
            donoDTO.setBairro_dono(tel_dono.getText());
            donoDTO.setCep_dono(cep_dono.getText());
            donoDTO.setCidade_dono(cidade_dono.getText());
            donoDTO.setEstado_dono(estado_dono.getSelectedItem().toString());
            
            JOptionPane.showMessageDialog(null, donoCTR.alterarDono(donoDTO));
        }
        catch(Exception e) {
            System.out.println("Erro ao gravar os dados" + e.getMessage());
        }
    }
    
    private void excluir(){
        if(JOptionPane.showConfirmDialog(null, "Deseja realmente excluir o pet?", "Aviso",
           JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            JOptionPane.showMessageDialog(null, donoCTR.excluirDono(donoDTO));
    }
     
    private void liberaCampos(boolean a) {
        nome_dono.setEnabled(a);
        cpf_dono.setEnabled(a);
        sexo_dono.setEnabled(a);
        nasc_dono.setEnabled(a);
        tel_dono.setEnabled(a);
        rua_dono.setEnabled(a);
        bairro_dono.setEnabled(a);
        cep_dono.setEnabled(a);
        cidade_dono.setEnabled(a);
        estado_dono.setEnabled(a);
    }
    
    private void liberaBotoes(boolean a, boolean b, boolean c, boolean d, boolean e){
        btnNovo.setEnabled(a);
        btnSalvar.setEnabled(b);
        btnCancelar.setEnabled(c);
        btnExcluir.setEnabled(d);
        btnSair.setEnabled(e);
    }
    
    private void limpaCampos(){
        nome_dono.setText("");
        cpf_dono.setText("");
        nasc_dono.setText("");
        tel_dono.setText("");
        rua_dono.setText("");
        bairro_dono.setText("");
        cep_dono.setText("");
        cidade_dono.setText("");
    }
    
    private void preencheTabela(String nome_dono){
        try{ 
            modelo_jtl_consultar_dono.setNumRows(0);
            
            donoDTO.setNome_dono(nome_dono);
            
            rs = donoCTR.consultarDono(donoDTO, 1); 
           
            while(rs.next()){
                modelo_jtl_consultar_dono.addRow(new Object[]{
                rs.getString("id_dono"),
                rs.getString("nome_dono"),
                });     
            }  
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
        finally{
            donoCTR.CloseDB();     
        }
    }
    
    private void preencheCampos(int id_dono){
        try{
            donoDTO.setId_dono(id_dono);
            
            rs = donoCTR.consultarDono(donoDTO, 2);
            
            if(rs.next()){
                limpaCampos();
            
                nome_dono.setText(rs.getString("nome_dono"));
                cpf_dono.setText(rs.getString("cpf_dono"));
                sexo_dono.setSelectedItem(rs.getString("sexo_dono"));
                nasc_dono.setText(rs.getString("nasc_dono"));
                tel_dono.setText(rs.getString("tel_dono"));
                rua_dono.setText(rs.getString("rua_dono"));
                num_dono.setText(rs.getString("num_dono"));
                bairro_dono.setText(rs.getString("bairro_dono"));
                cep_dono.setText(rs.getString("cep_dono"));
                cidade_dono.setText(rs.getString("cidade_dono"));
                estado_dono.setSelectedItem(rs.getString("estado_dono"));
               
                gravar_alterar = 2;
                 
                 liberaCampos(true);
               }
        }catch(Exception erTab){
            System.out.println("Erro SQL: "+erTab);  
        }finally{
            donoCTR.CloseDB();
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        nome_pet = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nome_dono = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cpf_dono = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        sexo_dono = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tel_dono = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rua_dono = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        num_dono = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        bairro_dono = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cep_dono = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        cidade_dono = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        estado_dono = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        pesquisa_nome_dono = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtl_consultar_dono = new javax.swing.JTable();
        nasc_dono = new javax.swing.JFormattedTextField();

        jLabel1.setText("jLabel1");

        nome_pet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nome_petActionPerformed(evt);
            }
        });

        jLabel11.setText("jLabel11");

        jLabel9.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 153));
        jLabel9.setText("CADASTRO DONO:");

        jLabel10.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 153, 153));
        jLabel10.setText("CADASTRO DONO:");

        jLabel2.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("NOME:");

        jLabel3.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("CPF:");

        jLabel4.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("SEXO:");

        sexo_dono.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        sexo_dono.setForeground(new java.awt.Color(0, 153, 153));
        sexo_dono.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "HOMEM ", "MULHER", " ", " " }));
        sexo_dono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexo_donoActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 51, 102));
        jLabel5.setText("NASCIMENTO:");

        jLabel6.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 102));
        jLabel6.setText("CELULAR:");

        tel_dono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tel_donoActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 102));
        jLabel7.setText("RUA:");

        jLabel8.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 102));
        jLabel8.setText("NUM:");

        jLabel12.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 51, 102));
        jLabel12.setText("BAIRRO:");

        jLabel13.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 51, 102));
        jLabel13.setText("CEP:");

        jLabel14.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 102));
        jLabel14.setText("CIDADE:");

        jLabel15.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 51, 102));
        jLabel15.setText("ESTADO:");

        estado_dono.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        estado_dono.setForeground(new java.awt.Color(0, 153, 153));
        estado_dono.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));

        jLabel16.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 153, 153));
        jLabel16.setText("CONSULTAR:");

        jLabel17.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 51, 102));
        jLabel17.setText("NOME:");

        btnPesquisar.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisar.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        btnSalvar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSalvar.setForeground(new java.awt.Color(0, 153, 0));
        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/salvar.png"))); // NOI18N
        btnSalvar.setText("SALVAR");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(153, 0, 0));
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnExcluir.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(153, 0, 0));
        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/excluir.png"))); // NOI18N
        btnExcluir.setText("EXCLUIR");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSair.setForeground(new java.awt.Color(204, 0, 0));
        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnSair.setText("SAIR");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnNovo.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnNovo.setForeground(new java.awt.Color(0, 153, 0));
        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/novo.png"))); // NOI18N
        btnNovo.setText(" NOVO");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        jtl_consultar_dono.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_dono.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_dono.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "NOME "
            }
        ));
        jtl_consultar_dono.setCellSelectionEnabled(true);
        jtl_consultar_dono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_donoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtl_consultar_dono);
        jtl_consultar_dono.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        try {
            nasc_dono.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(nome_dono))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cpf_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sexo_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cep_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(nasc_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jLabel6))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel7)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(rua_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(num_dono))
                                    .addComponent(tel_dono)))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bairro_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pesquisa_nome_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel16))
                        .addGap(0, 4, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cidade_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(estado_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNovo)
                .addGap(6, 6, 6)
                .addComponent(btnSalvar)
                .addGap(10, 10, 10)
                .addComponent(btnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnExcluir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSair)
                .addGap(100, 100, 100))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(jLabel16)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(nome_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel17)
                        .addComponent(pesquisa_nome_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnPesquisar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cpf_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(sexo_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(tel_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nasc_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(rua_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(num_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(bairro_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(cep_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cidade_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(estado_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNovo)
                    .addComponent(btnSalvar)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelar)
                        .addComponent(btnExcluir)
                        .addComponent(btnSair)))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sexo_donoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexo_donoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sexo_donoActionPerformed

    private void nome_petActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nome_petActionPerformed

    }//GEN-LAST:event_nome_petActionPerformed

    private void tel_donoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tel_donoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tel_donoActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        preencheTabela(pesquisa_nome_dono.getText().toUpperCase());
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if(gravar_alterar == 1){
            gravar();
            gravar_alterar = 0;
        }
        else{
            if(gravar_alterar == 2) {
                alterar();
                gravar_alterar = 0;
            }
            else
            JOptionPane.showMessageDialog(null, "Erro no Sistema!!");
        }

        limpaCampos();

        liberaCampos(false);

        liberaBotoes(true, false, false, false, true);
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpaCampos();

        liberaCampos(false);

        modelo_jtl_consultar_dono.setNumRows(0);

        liberaBotoes(true, false, false, false, true);

        gravar_alterar = 0;
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluir();

        limpaCampos();

        liberaCampos(false);

        liberaBotoes(true, false, false, false, true);

        modelo_jtl_consultar_dono.setNumRows(0);
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        liberaCampos(true);

        liberaBotoes(false, true, true, false, true);

        gravar_alterar = 1;
    }//GEN-LAST:event_btnNovoActionPerformed

    private void jtl_consultar_donoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_donoMouseClicked
        preencheCampos(Integer.parseInt(String.valueOf(
            jtl_consultar_dono.getValueAt(
                jtl_consultar_dono.getSelectedRow(), 0))));

        liberaBotoes(false, true, true, true, true);
    }//GEN-LAST:event_jtl_consultar_donoMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bairro_dono;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JTextField cep_dono;
    private javax.swing.JTextField cidade_dono;
    private javax.swing.JTextField cpf_dono;
    private javax.swing.JComboBox<String> estado_dono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtl_consultar_dono;
    private javax.swing.JFormattedTextField nasc_dono;
    private javax.swing.JTextField nome_dono;
    private javax.swing.JTextField nome_pet;
    private javax.swing.JTextField num_dono;
    private javax.swing.JTextField pesquisa_nome_dono;
    private javax.swing.JTextField rua_dono;
    private javax.swing.JComboBox<String> sexo_dono;
    private javax.swing.JTextField tel_dono;
    // End of variables declaration//GEN-END:variables
}

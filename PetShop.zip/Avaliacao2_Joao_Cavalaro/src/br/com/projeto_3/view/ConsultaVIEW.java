/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package br.com.projeto_3.view;

import java.awt.Dimension;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import br.com.projeto_3.dto.DonoDTO;
import br.com.projeto_3.ctr.DonoCTR;
import br.com.projeto_3.ctr.PetCTR;
import br.com.projeto_3.dto.PetDTO;
import br.com.projeto_3.ctr.VeterinarioCTR;
import br.com.projeto_3.dto.DonoDTO;
import br.com.projeto_3.dto.PetDTO;
import br.com.projeto_3.dto.VeterinarioDTO;
import br.com.projeto_3.dto.VeterinarioDTO;
import br.com.projeto_3.dto.ConsultaDTO;
import br.com.projeto_3.ctr.ConsultaCTR;
import java.util.Date;

public class ConsultaVIEW extends javax.swing.JInternalFrame {
    DonoCTR donoCTR = new DonoCTR();
    DonoDTO donoDTO = new DonoDTO();
    VeterinarioDTO veterinarioDTO = new VeterinarioDTO();
    VeterinarioCTR veterinarioCTR = new VeterinarioCTR();
    PetDTO petDTO = new PetDTO();
    PetCTR petCTR = new PetCTR();
    ConsultaDTO consultaDTO = new ConsultaDTO();
    ConsultaCTR consultaCTR = new ConsultaCTR();
    
    
    ResultSet rs;
    DefaultTableModel modelo_jtl_consultar_tipo;
    DefaultTableModel modelo_jtl_consultar_pet;
    DefaultTableModel modelo_jtl_consultar_tipo_selecionado;
     
    public ConsultaVIEW() {
        initComponents();
        
        this.liberaCampos(false);
        this.liberaBotoes(true, false, false, true);
        
        modelo_jtl_consultar_tipo = (DefaultTableModel) this.jtl_consultar_tipo.getModel();
        modelo_jtl_consultar_pet = (DefaultTableModel) this.jtl_consultar_pet.getModel();
        modelo_jtl_consultar_tipo_selecionado = (DefaultTableModel) this.jtl_consultar_tipo_selecionado.getModel();
    }
    private void gravar(){
        consultaDTO.setValor_consulta(Double.parseDouble(TotalConsulta.getText()));
        donoDTO.setId_dono(Integer.parseInt(String.valueOf(
            jtl_consultar_pet.getValueAt(jtl_consultar_pet.getSelectedRow(), 0))));
        
        JOptionPane.showMessageDialog(null, 
                consultaCTR.inserirConsulta(consultaDTO, veterinarioDTO, jtl_consultar_tipo_selecionado));
    }
    
    private void preencheTabelaCliente(String nome_dono){
        try{
            modelo_jtl_consultar_pet.setNumRows(0);
            
            donoDTO.setNome_dono(nome_dono);
            rs = donoCTR.consultarDono(donoDTO, 1);
            
            while(rs.next()){
                modelo_jtl_consultar_pet.addRow(new Object[]{
                    rs.getString("id_cliente"),
                    rs.getString("nome_cli")
            });
            }
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
    }
    
    private void preencheTabelaPet(String nome_pet){
        try{
            modelo_jtl_consultar_tipo.setNumRows(0);
            
            petDTO.setNome_pet(nome_pet);
            rs = petCTR.consultarPet(petDTO, 1);
            
            while(rs.next()){
                modelo_jtl_consultar_tipo.addRow(new Object[]{
                    rs.getString("id_pet"),
                    rs.getString("nome_pet"),
                    rs.getString("p_consulta_pet")
            });
            }
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
    }
    
    private void adicionaPetSelecionado(int id_pet, String nome_pet, double p_consulta_pet){
        try{
            modelo_jtl_consultar_tipo_selecionado.addRow(new Object[]{
                id_pet,
                nome_pet,
                p_consulta_pet
            });
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
    }
    
    private void removePetSelecionado(int linha_selecionada){
        try{
            if(linha_selecionada >= 0){
                modelo_jtl_consultar_tipo_selecionado.removeRow(linha_selecionada);
                calculaTotalConsulta();
            }
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
    }
    
    private void calculaTotalConsulta(){
        try{
            double total = 0;
            for(int cont =0; cont<jtl_consultar_tipo_selecionado.getRowCount(); cont++){
                total += (Double.parseDouble(String.valueOf(
                    jtl_consultar_tipo_selecionado.getValueAt(cont, 2))) *
                    Integer.parseInt(String.valueOf(
                    jtl_consultar_tipo_selecionado.getValueAt(cont, 3))));
            }
            TotalConsulta.setText(String.valueOf(total));
        }catch(Exception erTab){
            System.out.println("Erro SQL" + erTab);
        }
    }
    
    private void liberaCampos(boolean a){
        pesquisa_nome_pet.setEnabled(a);
        pesquisa_tipo_consulta.setEnabled(a);
        jtl_consultar_pet.setEnabled(a);
        jtl_consultar_tipo.setEnabled(a);
        jtl_consultar_tipo_selecionado.setEnabled(a);
        btnPesquisarConsulta.setEnabled(a);
        btnPesquisarPet.setEnabled(a);
        btnProAdd.setEnabled(a);
        btnProRem.setEnabled(a);
        TotalConsulta.setText("0.00");
    }
    
    private void limpaCampos(){
        pesquisa_nome_pet.setText("");
        pesquisa_tipo_consulta.setText("");
        modelo_jtl_consultar_pet.setNumRows(0);
        modelo_jtl_consultar_tipo.setNumRows(0);
        modelo_jtl_consultar_tipo_selecionado.setNumRows(0);
    }
    
    private void liberaBotoes(boolean a, boolean b, boolean c, boolean d){
        btnNovo.setEnabled(a);
        btnSalvar.setEnabled(b);
        btnCancelar.setEnabled(c);
        btnSair.setEnabled(d);
    }
    
    private boolean verificaPreenchimento(){
        if(jtl_consultar_pet.getSelectedRowCount() <= 0){
            JOptionPane.showMessageDialog(null, "Deve ser selecionado um Cliente");
            jtl_consultar_pet.requestFocus();
            return false;
        }
        else{
            if(jtl_consultar_tipo_selecionado.getRowCount() <= 0){
                    JOptionPane.showMessageDialog(null, "E necessario adicionar pelo menos um pet no pedido");
                    jtl_consultar_tipo_selecionado.requestFocus();
                    return false;
            }
            else{
                int verifica = 0;
                for(int cont=0; cont<jtl_consultar_tipo_selecionado.getRowCount(); cont++){
                    if(String.valueOf(jtl_consultar_tipo_selecionado.getValueAt(
                        cont, 3)).equalsIgnoreCase("null")){
                        verifica++;
                    }
                }
                if(verifica > 0){
                    JOptionPane.showMessageDialog(null,
                            "A quantidade de cada pet vendido deve ser informado");
                            jtl_consultar_tipo_selecionado.requestFocus();
                            return false;
                }
                else{
                    return true;
                }
            }
        }
    }
    private void removeTipoSelecionado(int linha_selecionada){
        try{
            if(linha_selecionada >= 0){
                modelo_jtl_consultar_tipo_selecionado.removeRow(linha_selecionada);
                calculaTotalConsulta();
            }
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pesquisa_nome_pet = new javax.swing.JTextField();
        btnPesquisarPet = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtl_consultar_pet = new javax.swing.JTable();
        btnSalvar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        btnCancelar = new javax.swing.JButton();
        TotalConsulta = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnSair = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnNovo = new javax.swing.JButton();
        pesquisa_tipo_consulta = new javax.swing.JTextField();
        btnProAdd = new javax.swing.JButton();
        btnPesquisarConsulta = new javax.swing.JButton();
        btnProRem = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtl_consultar_tipo_selecionado = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtl_consultar_tipo = new javax.swing.JTable();

        jLabel9.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 153));
        jLabel9.setText("MARCAR CONSULTA:");

        jLabel10.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 153, 153));
        jLabel10.setText("DADOS:");

        jLabel2.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("NOME DO PET:");

        btnPesquisarPet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisarPet.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisarPet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisarPet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarPetActionPerformed(evt);
            }
        });

        jtl_consultar_pet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_pet.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_pet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "NOME DO PET"
            }
        ));
        jtl_consultar_pet.setCellSelectionEnabled(true);
        jtl_consultar_pet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_petMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtl_consultar_pet);

        btnSalvar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSalvar.setForeground(new java.awt.Color(0, 153, 0));
        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/salvar.png"))); // NOI18N
        btnSalvar.setText("SALVAR");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 102, 204));
        jLabel11.setText("PREÇO CONSULTA:");

        btnCancelar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(153, 0, 0));
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        TotalConsulta.setFont(new java.awt.Font("Caviar Dreams", 1, 18)); // NOI18N
        TotalConsulta.setForeground(new java.awt.Color(0, 153, 102));
        TotalConsulta.setText("0.00");

        jLabel12.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 153, 153));
        jLabel12.setText("SERVIÇOS:");

        btnSair.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSair.setForeground(new java.awt.Color(204, 0, 0));
        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnSair.setText("SAIR");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("TIPO:");

        btnNovo.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnNovo.setForeground(new java.awt.Color(0, 153, 0));
        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/novo.png"))); // NOI18N
        btnNovo.setText(" NOVO");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        pesquisa_tipo_consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisa_tipo_consultaActionPerformed(evt);
            }
        });

        btnProAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/prod_add.png"))); // NOI18N
        btnProAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProAddActionPerformed(evt);
            }
        });

        btnPesquisarConsulta.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisarConsulta.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisarConsulta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisarConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarConsultaActionPerformed(evt);
            }
        });

        btnProRem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/prod_rem.png"))); // NOI18N
        btnProRem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProRemActionPerformed(evt);
            }
        });

        jtl_consultar_tipo_selecionado.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_tipo_selecionado.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_tipo_selecionado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "ID", "TIPO", "PREÇO", "QTD"
            }
        ));
        jtl_consultar_tipo_selecionado.setCellSelectionEnabled(true);
        jtl_consultar_tipo_selecionado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_tipo_selecionadoMouseClicked(evt);
            }
        });
        jtl_consultar_tipo_selecionado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtl_consultar_tipo_selecionadoKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jtl_consultar_tipo_selecionado);

        jtl_consultar_tipo.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_tipo.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_tipo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "ID", "TIPO", "PREÇO"
            }
        ));
        jtl_consultar_tipo.setCellSelectionEnabled(true);
        jtl_consultar_tipo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_tipoMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jtl_consultar_tipo);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesquisa_nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(btnPesquisarPet, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel10)
                    .addComponent(jLabel9)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TotalConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pesquisa_tipo_consulta)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnPesquisarConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(btnProAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)
                        .addComponent(btnProRem, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(btnNovo)
                .addGap(6, 6, 6)
                .addComponent(btnSalvar)
                .addGap(10, 10, 10)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnPesquisarPet)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(pesquisa_nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(pesquisa_tipo_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(btnPesquisarConsulta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(TotalConsulta, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnProAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnProRem, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNovo)
                    .addComponent(btnSalvar)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelar)
                        .addComponent(btnSair)))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPesquisarPetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarPetActionPerformed
        preencheTabelaPet(pesquisa_nome_pet.getText().toUpperCase());
    }//GEN-LAST:event_btnPesquisarPetActionPerformed

    private void jtl_consultar_petMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_petMouseClicked

    }//GEN-LAST:event_jtl_consultar_petMouseClicked

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if(verificaPreenchimento()){
            gravar();
            limpaCampos();
            liberaCampos(false);
            liberaBotoes(true, false, false, true);
        }
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpaCampos();

        liberaCampos(false);

        modelo_jtl_consultar_pet.setNumRows(0);

        liberaBotoes(true, false, false, true);

        
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        liberaCampos(true);

        liberaBotoes(false, true, true, true);

        
    }//GEN-LAST:event_btnNovoActionPerformed

    private void pesquisa_tipo_consultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisa_tipo_consultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesquisa_tipo_consultaActionPerformed

    private void btnProAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProAddActionPerformed
         adicionaPetSelecionado(
            Integer.parseInt(String.valueOf(jtl_consultar_tipo.getValueAt(
                jtl_consultar_tipo.getSelectedRow(), 0))),
            String.valueOf(jtl_consultar_tipo.getValueAt(jtl_consultar_tipo.getSelectedRow(), 1)),
            Double.parseDouble(String.valueOf(jtl_consultar_tipo.getValueAt(
                jtl_consultar_tipo.getSelectedRow(), 2))));
    }//GEN-LAST:event_btnProAddActionPerformed

    private void btnPesquisarConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarConsultaActionPerformed
        
    }//GEN-LAST:event_btnPesquisarConsultaActionPerformed

    private void btnProRemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProRemActionPerformed
        removeTipoSelecionado(jtl_consultar_tipo_selecionado.getSelectedRow());
    }//GEN-LAST:event_btnProRemActionPerformed

    private void jtl_consultar_tipo_selecionadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_tipo_selecionadoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jtl_consultar_tipo_selecionadoMouseClicked

    private void jtl_consultar_tipoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_tipoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jtl_consultar_tipoMouseClicked

    private void jtl_consultar_tipo_selecionadoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtl_consultar_tipo_selecionadoKeyReleased
          if(evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER){
            calculaTotalConsulta();
          }
    }//GEN-LAST:event_jtl_consultar_tipo_selecionadoKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TotalConsulta;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnPesquisarConsulta;
    private javax.swing.JButton btnPesquisarPet;
    private javax.swing.JButton btnProAdd;
    private javax.swing.JButton btnProRem;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jtl_consultar_pet;
    private javax.swing.JTable jtl_consultar_tipo;
    private javax.swing.JTable jtl_consultar_tipo_selecionado;
    private javax.swing.JTextField pesquisa_nome_pet;
    private javax.swing.JTextField pesquisa_tipo_consulta;
    // End of variables declaration//GEN-END:variables
}

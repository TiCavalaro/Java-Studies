package br.com.projeto_3.view;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import br.com.projeto_3.dto.VeterinarioDTO;
import br.com.projeto_3.ctr.VeterinarioCTR;
import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.text.ParseException;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;

public class VeterinarioVIEW extends javax.swing.JInternalFrame {
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    VeterinarioDTO veterinarioDTO = new VeterinarioDTO();
    VeterinarioCTR veterinarioCTR = new VeterinarioCTR();
    
    int gravar_alterar;
    
    
    ResultSet rs;
    DefaultTableModel modelo_jtl_consultar_vet;
    
    public VeterinarioVIEW() {
        initComponents();
        
        initComponents();
        
        liberaCampos(false);
        
        liberaBotoes(true, false, false, false, true);
        
        modelo_jtl_consultar_vet = (DefaultTableModel) jtl_consultar_vet.getModel();
    }
    
    public void setPosicao() {
        
        Dimension d = this.getDesktopPane().getSize();
        this.setLocation((d.width - this.getSize().width) / 2, (d.height - this.getSize().height) / 2);
    }
    
    public void gravar(){
        try{
            veterinarioDTO.setNome_vet(nome_vet.getText());
            veterinarioDTO.setCpf_vet(cpf_vet.getText());
            veterinarioDTO.setSexo_vet(sexo_vet.getSelectedItem().toString());
            veterinarioDTO.setNasc_vet(data_format.parse(nasc_vet.getText()));
            veterinarioDTO.setTel_vet(tel_vet.getText());
            veterinarioDTO.setRua_vet(rua_vet.getText());
            veterinarioDTO.setNum_vet(num_vet.getText());
            veterinarioDTO.setBairro_vet(bairro_vet.getText());
            veterinarioDTO.setCep_vet(cep_vet.getText());
            veterinarioDTO.setCidade_vet(cidade_vet.getText());
            veterinarioDTO.setEstado_vet(estado_vet.getSelectedItem().toString());
            veterinarioDTO.setCrmv_vet(crmv_vet.getText());
            veterinarioDTO.setEspecialidade_vet(especialidade_vet.getSelectedItem().toString());
            
            JOptionPane.showMessageDialog(null, veterinarioCTR.inserirVeterinario(veterinarioDTO));     
        }

        catch(Exception e) {
            System.out.println("Erro ao Gravar" + e.getMessage());
        }
    }
    
    private void alterar(){
        try{  
            veterinarioDTO.setNome_vet(nome_vet.getText());
            veterinarioDTO.setCpf_vet(cpf_vet.getText());
            veterinarioDTO.setSexo_vet(sexo_vet.getSelectedItem().toString());
            veterinarioDTO.setNasc_vet(data_format.parse(nasc_vet.getText()));
            veterinarioDTO.setTel_vet(tel_vet.getText());
            veterinarioDTO.setRua_vet(rua_vet.getText());
            veterinarioDTO.setNum_vet(num_vet.getText());
            veterinarioDTO.setBairro_vet(bairro_vet.getText());
            veterinarioDTO.setCep_vet(cep_vet.getText());
            veterinarioDTO.setCidade_vet(cidade_vet.getText());
            veterinarioDTO.setCrmv_vet(crmv_vet.getText());
            veterinarioDTO.setEspecialidade_vet(especialidade_vet.getSelectedItem().toString());
            
            JOptionPane.showMessageDialog(null, veterinarioCTR.alterarVeterinario(veterinarioDTO));
        }   
        catch(Exception e){   
            System.out.println("Erro ao Alterar " + e.getMessage());
        }
    }
    
    private void excluir() {
        if(JOptionPane.showConfirmDialog(null,"Deseja realmente excluir o veterinário?","Aviso",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
            JOptionPane.showMessageDialog(null, veterinarioCTR.excluirVeterinario(veterinarioDTO));
        }
    }
    
     private void liberaCampos(boolean a) {
        nome_vet.setEnabled(a);
        cpf_vet.setEnabled(a);
        sexo_vet.setEnabled(a);
        nasc_vet.setEnabled(a);
        tel_vet.setEnabled(a);
        rua_vet.setEnabled(a);
        num_vet.setEnabled(a);
        bairro_vet.setEnabled(a);
        cep_vet.setEnabled(a);
        cidade_vet.setEnabled(a);
        estado_vet.setEnabled(a);
        crmv_vet.setEnabled(a);
        especialidade_vet.setEnabled(a);
    }
     
    private void liberaBotoes(boolean a, boolean b, boolean c, boolean d, boolean e){
        btnNovo.setEnabled(a);
        btnSalvar.setEnabled(b);
        btnCancelar.setEnabled(c);
        btnExcluir.setEnabled(d);
        btnSair.setEnabled(e);
    }
    
    private void limpaCampos(){
        nome_vet.setText("");
        cpf_vet.setText("");
        nasc_vet.setText("");
        tel_vet.setText("");
        rua_vet.setText("");
        num_vet.setText("");
        bairro_vet.setText("");
        cep_vet.setText("");
        cidade_vet.setText("");
        crmv_vet.setText(""); 
    }
    
    private void preencheTabela(String nome_vet){
        try{          
            modelo_jtl_consultar_vet.setNumRows(0);
            veterinarioDTO.setNome_vet(nome_vet);
            
            rs = veterinarioCTR.consultarVeterinario(veterinarioDTO, 1);
            
            while(rs.next()) {         
                modelo_jtl_consultar_vet.addRow(new Object[]{
                    rs.getString("id_vet"),
                    rs.getString("nome_vet"),
                });
            }
        }
        catch(Exception erTab){
            System.out.println("ERRO SQL: "+erTab);
        }
        finally{
            veterinarioCTR.CloseDB();
        }
    }
    
    private void preencheCampos(int id_vet){
        try{
            veterinarioDTO.setId_vet(id_vet);
            rs = veterinarioCTR.consultarVeterinario(veterinarioDTO, 2);
            
            if(rs.next()) {
                limpaCampos();
                
                nome_vet.setText(rs.getString("nome_vet"));
                cpf_vet.setText(rs.getString("cpf_vet"));
                sexo_vet.setSelectedItem(rs.getString("sexo_vet"));
                nasc_vet.setText(rs.getString("nasc_vet"));
                tel_vet.setText(rs.getString("tel_vet"));
                rua_vet.setText(rs.getString("rua_vet"));
                num_vet.setText(rs.getString("num_vet"));
                bairro_vet.setText(rs.getString("bairro_vet"));
                cep_vet.setText(rs.getString("cep_vet"));
                cidade_vet.setText(rs.getString("cidade_vet"));
                estado_vet.setSelectedItem(rs.getString("estado_vet"));
                crmv_vet.setText(rs.getString("crmv_vet"));
                especialidade_vet.setSelectedItem(rs.getString("especialidae_vet"));
                
                gravar_alterar = 2;
                liberaCampos(true);       
            }
        }
        catch(Exception erTab){            
            System.out.println("ERRO SQL: " +erTab);            
        }
        finally{
            veterinarioCTR.CloseDB();
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        nome_vet = new javax.swing.JTextField();
        cpf_vet = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        sexo_vet = new javax.swing.JComboBox<>();
        nasc_vet = new javax.swing.JFormattedTextField();
        tel_vet = new javax.swing.JTextField();
        rua_vet = new javax.swing.JTextField();
        num_vet = new javax.swing.JTextField();
        bairro_vet = new javax.swing.JTextField();
        cep_vet = new javax.swing.JTextField();
        cidade_vet = new javax.swing.JTextField();
        estado_vet = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();
        pesquisa_nome_vet = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtl_consultar_vet = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        crmv_vet = new javax.swing.JTextField();
        especialidade_vet = new javax.swing.JComboBox<>();

        jLabel9.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 153));
        jLabel9.setText("CADASTRO VETERINÁRIO:");

        jLabel2.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("NOME:");

        jLabel3.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("CPF:");

        jLabel5.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 51, 102));
        jLabel5.setText("NASCIMENTO:");

        jLabel7.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 102));
        jLabel7.setText("RUA:");

        jLabel12.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 51, 102));
        jLabel12.setText("BAIRRO:");

        jLabel13.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 51, 102));
        jLabel13.setText("CEP:");

        jLabel14.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 102));
        jLabel14.setText("CIDADE:");

        jLabel15.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 51, 102));
        jLabel15.setText("ESTADO:");

        jLabel4.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("SEXO:");

        jLabel6.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 102));
        jLabel6.setText("CELULAR:");

        jLabel8.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 102));
        jLabel8.setText("NUM:");

        sexo_vet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        sexo_vet.setForeground(new java.awt.Color(0, 153, 153));
        sexo_vet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "HOMEM", "MULHER", " " }));

        try {
            nasc_vet.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        estado_vet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        estado_vet.setForeground(new java.awt.Color(0, 153, 153));
        estado_vet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC" }));

        jLabel16.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 153, 153));
        jLabel16.setText("CONSULTAR:");

        jLabel17.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 51, 102));
        jLabel17.setText("NOME:");

        btnSalvar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSalvar.setForeground(new java.awt.Color(0, 153, 0));
        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/salvar.png"))); // NOI18N
        btnSalvar.setText("SALVAR");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(153, 0, 0));
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnExcluir.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(153, 0, 0));
        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/excluir.png"))); // NOI18N
        btnExcluir.setText("EXCLUIR");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSair.setForeground(new java.awt.Color(204, 0, 0));
        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnSair.setText("SAIR");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnNovo.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnNovo.setForeground(new java.awt.Color(0, 153, 0));
        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/novo.png"))); // NOI18N
        btnNovo.setText(" NOVO");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        pesquisa_nome_vet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisa_nome_vetActionPerformed(evt);
            }
        });

        btnPesquisar.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisar.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        jtl_consultar_vet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_vet.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_vet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "NOME"
            }
        ));
        jtl_consultar_vet.setCellSelectionEnabled(true);
        jtl_consultar_vet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_vetMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtl_consultar_vet);
        jtl_consultar_vet.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        jLabel18.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 51, 102));
        jLabel18.setText("ESPECIALIDADE:");

        jLabel19.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 51, 102));
        jLabel19.setText("CRMV:");

        especialidade_vet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        especialidade_vet.setForeground(new java.awt.Color(0, 153, 153));
        especialidade_vet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DERMATOLOGIA", "MEDICINA VETERINÁRIA INTENSIVA", "ACUPUNTURA", "ONCOLOGIA", "PATOLOGIA", "CIRURGIA VETERINÁRIA", "ANESRESIOLOGIA", "HOMEOPATIA" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel9)
                        .addGap(190, 190, 190)
                        .addComponent(jLabel16))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(4, 4, 4)
                                .addComponent(nome_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pesquisa_nome_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(4, 4, 4)
                                        .addComponent(cpf_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(4, 4, 4)
                                        .addComponent(jLabel4)
                                        .addGap(4, 4, 4)
                                        .addComponent(sexo_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(4, 4, 4)
                                        .addComponent(nasc_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(4, 4, 4)
                                        .addComponent(jLabel6)
                                        .addGap(6, 6, 6)
                                        .addComponent(tel_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(4, 4, 4)
                                        .addComponent(rua_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel8)
                                        .addGap(4, 4, 4)
                                        .addComponent(num_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addGap(4, 4, 4)
                                        .addComponent(bairro_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addGap(4, 4, 4)
                                        .addComponent(cep_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(39, 39, 39)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(4, 4, 4)
                                .addComponent(cidade_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(4, 4, 4)
                                .addComponent(estado_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(especialidade_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(crmv_vet, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(13, 13, 13))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(btnNovo)
                .addGap(3, 3, 3)
                .addComponent(btnSalvar)
                .addGap(11, 11, 11)
                .addComponent(btnCancelar)
                .addGap(3, 3, 3)
                .addComponent(btnExcluir)
                .addGap(5, 5, 5)
                .addComponent(btnSair)
                .addGap(103, 103, 103))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel9))
                    .addComponent(jLabel16))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel2))
                                    .addComponent(nome_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel17)
                                    .addComponent(pesquisa_nome_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(3, 3, 3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnPesquisar)
                        .addGap(1, 1, 1)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(cpf_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel4))
                            .addComponent(sexo_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nasc_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tel_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rua_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(num_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8))))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel12))
                            .addComponent(bairro_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel13))
                            .addComponent(cep_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel14))
                    .addComponent(cidade_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel15))
                    .addComponent(estado_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(crmv_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(especialidade_vet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNovo)
                    .addComponent(btnSalvar)
                    .addComponent(btnCancelar)
                    .addComponent(btnExcluir)
                    .addComponent(btnSair))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if(gravar_alterar == 1){
            gravar();
            gravar_alterar = 0;
        }
        else{
            if(gravar_alterar == 2) {
                alterar();
                gravar_alterar = 0;
            }
            else
            JOptionPane.showMessageDialog(null, "Erro no Sistema!!");
        }

        limpaCampos();

        liberaCampos(false);

        liberaBotoes(true, false, false, false, true);
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpaCampos();

        liberaCampos(false);

        modelo_jtl_consultar_vet.setNumRows(0);

        liberaBotoes(true, false, false, false, true);

        gravar_alterar = 0;
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluir();

        limpaCampos();

        liberaCampos(false);

        liberaBotoes(true, false, false, false, true);

        modelo_jtl_consultar_vet.setNumRows(0);
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        liberaCampos(true);

        liberaBotoes(false, true, true, false, true);

        gravar_alterar = 1;
    }//GEN-LAST:event_btnNovoActionPerformed

    private void pesquisa_nome_vetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisa_nome_vetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesquisa_nome_vetActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        preencheTabela(pesquisa_nome_vet.getText().toUpperCase());
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void jtl_consultar_vetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_vetMouseClicked
        preencheCampos(Integer.parseInt(String.valueOf(
            jtl_consultar_vet.getValueAt(
                jtl_consultar_vet.getSelectedRow(), 0))));

        liberaBotoes(false, true, true, true, true);
    }//GEN-LAST:event_jtl_consultar_vetMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bairro_vet;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JTextField cep_vet;
    private javax.swing.JTextField cidade_vet;
    private javax.swing.JTextField cpf_vet;
    private javax.swing.JTextField crmv_vet;
    private javax.swing.JComboBox<String> especialidade_vet;
    private javax.swing.JComboBox<String> estado_vet;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtl_consultar_vet;
    private javax.swing.JFormattedTextField nasc_vet;
    private javax.swing.JTextField nome_vet;
    private javax.swing.JTextField num_vet;
    private javax.swing.JTextField pesquisa_nome_vet;
    private javax.swing.JTextField rua_vet;
    private javax.swing.JComboBox<String> sexo_vet;
    private javax.swing.JTextField tel_vet;
    // End of variables declaration//GEN-END:variables
}

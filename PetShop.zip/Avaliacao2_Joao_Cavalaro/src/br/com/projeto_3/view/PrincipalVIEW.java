package br.com.projeto_3.view;
import javax.swing.JOptionPane;
import java.awt.Image;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class PrincipalVIEW extends javax.swing.JFrame{
    
    public PrincipalVIEW() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    private void sair(){
       Object[] options = {"Sair", "Cancelar"};
       if (JOptionPane.showOptionDialog(null,"Deseja sair do sistema?", "Informação", 
               JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]) == 0) { 
           System.exit(0);
       }
    }
    
    private void abreDonoVIEW(){
        DonoVIEW donoVIEW = new DonoVIEW();
        this.desktopPane.add(donoVIEW);
        donoVIEW.setVisible(true);
        donoVIEW.setPosicao();
    }
    
    private void abrePetVIEW(){
        PetVIEW petVIEW = new PetVIEW();
        this.desktopPane.add(petVIEW);
        petVIEW.setVisible(true);
        petVIEW.setPosicao();
    }
    
    private void abreVeterinarioVIEW(){
        VeterinarioVIEW veterinarioVIEW = new VeterinarioVIEW();
        this.desktopPane.add(veterinarioVIEW);
        veterinarioVIEW.setVisible(true);
        veterinarioVIEW.setPosicao();
    }
    
   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalVIEW().setVisible(true);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        itemMenuVeterinario = new javax.swing.JMenu();
        itemMenuPet = new javax.swing.JMenuItem();
        itemMenuDono = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        menuConsulta = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        menuSair = new javax.swing.JMenu();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        itemMenuVeterinario.setForeground(new java.awt.Color(0, 153, 153));
        itemMenuVeterinario.setText("CADASTRO");
        itemMenuVeterinario.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N

        itemMenuPet.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        itemMenuPet.setForeground(new java.awt.Color(0, 153, 153));
        itemMenuPet.setText("PET");
        itemMenuPet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemMenuPetActionPerformed(evt);
            }
        });
        itemMenuVeterinario.add(itemMenuPet);

        itemMenuDono.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        itemMenuDono.setForeground(new java.awt.Color(0, 153, 153));
        itemMenuDono.setText("DONO");
        itemMenuDono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemMenuDonoActionPerformed(evt);
            }
        });
        itemMenuVeterinario.add(itemMenuDono);

        jMenuItem3.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jMenuItem3.setForeground(new java.awt.Color(0, 153, 153));
        jMenuItem3.setText("VETERINÁRIO");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        itemMenuVeterinario.add(jMenuItem3);

        menuBar.add(itemMenuVeterinario);

        menuConsulta.setForeground(new java.awt.Color(0, 153, 153));
        menuConsulta.setText("CONSULTA");
        menuConsulta.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N

        jMenuItem1.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jMenuItem1.setForeground(new java.awt.Color(0, 153, 153));
        jMenuItem1.setText("MARCAR CONSULTA");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        menuConsulta.add(jMenuItem1);

        menuBar.add(menuConsulta);

        menuSair.setForeground(new java.awt.Color(0, 102, 255));
        menuSair.setMnemonic('e');
        menuSair.setText("SAIR");
        menuSair.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        menuSair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuSairMouseClicked(evt);
            }
        });
        menuBar.add(menuSair);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 968, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(desktopPane, javax.swing.GroupLayout.PREFERRED_SIZE, 619, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuSairMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuSairMouseClicked
         sair();
    }//GEN-LAST:event_menuSairMouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void itemMenuPetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemMenuPetActionPerformed
        abrePetVIEW();
    }//GEN-LAST:event_itemMenuPetActionPerformed

    private void itemMenuDonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemMenuDonoActionPerformed
      abreDonoVIEW();
    }//GEN-LAST:event_itemMenuDonoActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        abreVeterinarioVIEW();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem itemMenuDono;
    private javax.swing.JMenuItem itemMenuPet;
    private javax.swing.JMenu itemMenuVeterinario;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuConsulta;
    private javax.swing.JMenu menuSair;
    // End of variables declaration//GEN-END:variables

}

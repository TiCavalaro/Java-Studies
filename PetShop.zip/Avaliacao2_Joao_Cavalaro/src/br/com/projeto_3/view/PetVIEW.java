package br.com.projeto_3.view;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import br.com.projeto_3.dto.PetDTO;
import br.com.projeto_3.ctr.PetCTR;
import br.com.projeto_3.dto.DonoDTO;
import br.com.projeto_3.ctr.DonoCTR;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;

public class PetVIEW extends javax.swing.JInternalFrame {
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    PetDTO petDTO = new PetDTO();
    PetCTR petCTR = new PetCTR();
    DonoDTO donoDTO = new DonoDTO();
    DonoCTR donoCTR = new DonoCTR();
    
    int gravar_alterar;
    
    ResultSet rs;
    
    DefaultTableModel modelo_jtl_consultar_pet;
    DefaultTableModel modelo_jtl_consultar_dono;
    
    public PetVIEW() {
        initComponents();
        
        liberaCampos(false);
        
        liberaBotoes(true, false, false, false, true);
        
        modelo_jtl_consultar_pet = (DefaultTableModel) jtl_consultar_pet.getModel();
        modelo_jtl_consultar_dono = (DefaultTableModel) jtl_consultar_dono.getModel();
    }
    
    public void setPosicao() {
        Dimension d = this.getDesktopPane().getSize();
        this.setLocation((d.width - this.getSize().width) / 2, (d.height - this.getSize().height) / 2);
    } 
    
    private void gravar(){ 
        try{
            petDTO.setNome_pet(nome_pet.getText());
            petDTO.setRga_pet(rga_pet.getText());
            petDTO.setSexo_pet(sexo_pet.getSelectedItem().toString());
            petDTO.setNasc_vet(data_format.parse(nasc_pet.getText()));
            petDTO.setRaca_pet(raca_pet.getText());
            petDTO.setCor_pet(cor_pet.getText());
            donoDTO.setId_dono(Integer.parseInt(String.valueOf(
                    jtl_consultar_dono.getValueAt(
                    jtl_consultar_dono.getSelectedRow(), 0))));
            
            JOptionPane.showMessageDialog(null, petCTR.inserirPet(petDTO, donoDTO));
        }
        catch(Exception e) {
            System.out.println("Erro ao gravar os dados" + e.getMessage());
        }
    }
    
    private void alterar(){ 
        try{
            petDTO.setNome_pet(nome_pet.getText());
            petDTO.setRga_pet(rga_pet.getText());
            petDTO.setSexo_pet(sexo_pet.getSelectedItem().toString());
            petDTO.setNasc_vet(data_format.parse(nasc_pet.getText()));
            petDTO.setRaca_pet(raca_pet.getText());
            petDTO.setCor_pet(cor_pet.getText());
            donoDTO.setId_dono(Integer.parseInt(String.valueOf(
                    jtl_consultar_dono.getValueAt(
                    jtl_consultar_dono.getSelectedRow(), 0))));
            
            JOptionPane.showMessageDialog(null, petCTR.alterarPet(petDTO, donoDTO));
        }
        catch(Exception e) {
            System.out.println("Erro ao gravar os dados" + e.getMessage());
        }
    }
    
    private void excluir(){
        if(JOptionPane.showConfirmDialog(null, "Deseja realmente excluir o pet?", "Aviso",
           JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            JOptionPane.showMessageDialog(null, petCTR.excluirPet(petDTO));
    }
     
    private void liberaCampos(boolean a) {
        nome_pet.setEnabled(a);
        rga_pet.setEnabled(a);
        sexo_pet.setEnabled(a);
        nasc_pet.setEnabled(a);
        raca_pet.setEnabled(a);
        cor_pet.setEnabled(a);
        pesquisa_nome_dono.setEnabled(a);
        btnPesquisarDono.setEnabled(a);
        jtl_consultar_dono.setEnabled(a);
    }
    
    private void liberaBotoes(boolean a, boolean b, boolean c, boolean d, boolean e){
        btnNovo.setEnabled(a);
        btnSalvar.setEnabled(b);
        btnCancelar.setEnabled(c);
        btnExcluir.setEnabled(d);
        btnSair.setEnabled(e);
    }
    
    private void limpaCampos(){
        nome_pet.setText("");
        rga_pet.setText("");
        nasc_pet.setText("");
        raca_pet.setText("");
        cor_pet.setText("");
        pesquisa_nome_dono.setText("");
        modelo_jtl_consultar_dono.setNumRows(0);
    }
    
    private void preencheTabelaPet(String nome_pet){
        try{ 
            modelo_jtl_consultar_pet.setNumRows(0);
            
            petDTO.setNome_pet(nome_pet);
            
            rs = petCTR.consultarPet(petDTO, 1); 
           
            while(rs.next()){
                modelo_jtl_consultar_pet.addRow(new Object[]{
                rs.getString("id_pet"),
                rs.getString("nome_pet"),
                });     
            }  
        }catch(Exception erTab){
            System.out.println("Erro SQL: " + erTab);
        }
        finally{
            petCTR.CloseDB();     
        }
    }
    
    private void preencheCamposPet(int id_pet){
        try{
            petDTO.setId_pet(id_pet);
            
            rs = petCTR.consultarPet(petDTO, 2);
            
            if(rs.next()){
                limpaCampos();
            
                nome_pet.setText(rs.getString("nome_pet"));
                rga_pet.setText(rs.getString("rga_pet"));
                sexo_pet.setSelectedItem(rs.getString("sexo_pet"));
                nasc_pet.setText(rs.getString("nasc_pet"));
                raca_pet.setText(rs.getString("raca"));
                cor_pet.setText(rs.getString("cor_pet"));
                
                modelo_jtl_consultar_dono.setNumRows(0);
                modelo_jtl_consultar_dono.addRow(new Object[] {rs.getInt("id_dono"), rs.getString("nome_dono"),});
                jtl_consultar_dono.setRowSelectionInterval(0, 0);

                 gravar_alterar = 2;
                 
                 liberaCampos(true);
               }
        }catch(Exception erTab){
            System.out.println("Erro SQL: "+erTab);  
        }finally{
            petCTR.CloseDB();
        }
    }
    
    private void preencheTabelaDono(String nome_dono){
        try{
            modelo_jtl_consultar_dono.setNumRows(0);
          
            donoDTO.setNome_dono(nome_dono);
            
            rs = donoCTR.consultarDono(donoDTO, 1);
            
            while(rs.next()){
                modelo_jtl_consultar_dono.addRow(new Object[]{
                rs.getString("id_dono"),
                rs.getString("nome_dono"),
                });
            }
        }
        catch (Exception erTab){
            System.out.println("Erro SQL: "+erTab);
        }
        finally{
            donoCTR.CloseDB();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        nome_pet = new javax.swing.JTextField();
        rga_pet = new javax.swing.JTextField();
        raca_pet = new javax.swing.JTextField();
        cor_pet = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        pesquisa_nome_pet = new javax.swing.JTextField();
        btnPesquisarPet = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtl_consultar_pet = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnNovo = new javax.swing.JButton();
        sexo_pet = new javax.swing.JComboBox<>();
        nasc_pet = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        pesquisa_nome_dono = new javax.swing.JTextField();
        btnPesquisarDono = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtl_consultar_dono = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("RAÇA:");

        jLabel4.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("NASCIMENTO: ");

        jLabel5.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 51, 102));
        jLabel5.setText("COR:");

        jLabel6.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 102));
        jLabel6.setText("SEXO:");

        jLabel1.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setText("CADASTRAR PET");

        jLabel8.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 102));
        jLabel8.setText("RGA:");

        nome_pet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nome_petActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("NOME:");

        jLabel12.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 153, 153));
        jLabel12.setText("CONSULTAR");

        btnPesquisarPet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisarPet.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisarPet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisarPet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarPetActionPerformed(evt);
            }
        });

        jtl_consultar_pet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_pet.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_pet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "NOME DO PET"
            }
        ));
        jtl_consultar_pet.setCellSelectionEnabled(true);
        jtl_consultar_pet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_petMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtl_consultar_pet);
        jtl_consultar_pet.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        jLabel15.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 51, 102));
        jLabel15.setText("NOME:");

        btnSalvar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSalvar.setForeground(new java.awt.Color(0, 153, 0));
        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/salvar.png"))); // NOI18N
        btnSalvar.setText("SALVAR");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(153, 0, 0));
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnExcluir.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnExcluir.setForeground(new java.awt.Color(153, 0, 0));
        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/excluir.png"))); // NOI18N
        btnExcluir.setText("EXCLUIR");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnSair.setForeground(new java.awt.Color(204, 0, 0));
        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/cancelar.png"))); // NOI18N
        btnSair.setText("SAIR");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnNovo.setFont(new java.awt.Font("Caviar Dreams", 1, 10)); // NOI18N
        btnNovo.setForeground(new java.awt.Color(0, 153, 0));
        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/novo.png"))); // NOI18N
        btnNovo.setText(" NOVO");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        sexo_pet.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        sexo_pet.setForeground(new java.awt.Color(0, 153, 153));
        sexo_pet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MACHO", "FÊMEA", " " }));

        nasc_pet.setText(" / /");

        jLabel7.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 102));
        jLabel7.setText("DONO:");

        btnPesquisarDono.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        btnPesquisarDono.setForeground(new java.awt.Color(0, 153, 51));
        btnPesquisarDono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/projeto_3/view/imagens/pesquisar.png"))); // NOI18N
        btnPesquisarDono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarDonoActionPerformed(evt);
            }
        });

        jtl_consultar_dono.setFont(new java.awt.Font("Caviar Dreams", 1, 12)); // NOI18N
        jtl_consultar_dono.setForeground(new java.awt.Color(0, 153, 153));
        jtl_consultar_dono.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "ID", "NOME "
            }
        ));
        jtl_consultar_dono.setCellSelectionEnabled(true);
        jtl_consultar_dono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtl_consultar_donoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jtl_consultar_dono);
        jtl_consultar_dono.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnNovo)
                        .addGap(6, 6, 6)
                        .addComponent(btnSalvar)
                        .addGap(10, 10, 10)
                        .addComponent(btnCancelar)
                        .addGap(0, 439, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel1)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(4, 4, 4)
                                            .addComponent(nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(38, 38, 38)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel12)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel15)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(pesquisa_nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(5, 5, 5)
                                    .addComponent(btnPesquisarPet, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(pesquisa_nome_dono, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnPesquisarDono, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(1, 1, 1))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(rga_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel6)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(sexo_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addGap(4, 4, 4)
                                                .addComponent(nasc_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(raca_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(4, 4, 4)
                                                .addComponent(cor_pet, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGap(38, 38, 38)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(btnExcluir)
                .addGap(10, 10, 10)
                .addComponent(btnSair)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel2))
                            .addComponent(nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(pesquisa_nome_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(btnPesquisarPet)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(rga_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(sexo_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(nasc_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(raca_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cor_pet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pesquisa_nome_dono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnPesquisarDono)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNovo)
                    .addComponent(btnSalvar)
                    .addComponent(btnCancelar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnExcluir)
                    .addComponent(btnSair)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nome_petActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nome_petActionPerformed

    }//GEN-LAST:event_nome_petActionPerformed

    private void btnPesquisarPetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarPetActionPerformed
        preencheTabelaPet(pesquisa_nome_pet.getText());
    }//GEN-LAST:event_btnPesquisarPetActionPerformed

    private void jtl_consultar_petMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_petMouseClicked
        preencheCamposPet(Integer.parseInt(String.valueOf(
            jtl_consultar_pet.getValueAt(
            jtl_consultar_pet.getSelectedRow(), 0))));

        liberaBotoes(false, true, true, true, true);
    }//GEN-LAST:event_jtl_consultar_petMouseClicked

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        if(gravar_alterar == 1){
            gravar();
            gravar_alterar = 0;
        }
        else{
            if(gravar_alterar == 2) {
                alterar();
                gravar_alterar = 0;
            }
            else
                JOptionPane.showMessageDialog(null, "Erro no Sistema!!");
        }

        limpaCampos();
        
        liberaCampos(false);
        
        liberaBotoes(true, false, false, false, true);
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpaCampos();
        
        liberaCampos(false);
        
        modelo_jtl_consultar_pet.setNumRows(0);
        
        liberaBotoes(true, false, false, false, true);
        
        gravar_alterar = 0;
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        excluir();
        
        limpaCampos();
        
        liberaCampos(false);
        
        liberaBotoes(true, false, false, false, true);
        
        modelo_jtl_consultar_pet.setNumRows(0);
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        liberaCampos(true);
        
        liberaBotoes(false, true, true, false, true);
        
        gravar_alterar = 1;
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnPesquisarDonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarDonoActionPerformed
        preencheTabelaDono(pesquisa_nome_dono.getText());
    }//GEN-LAST:event_btnPesquisarDonoActionPerformed

    private void jtl_consultar_donoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtl_consultar_donoMouseClicked

    }//GEN-LAST:event_jtl_consultar_donoMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnPesquisarDono;
    private javax.swing.JButton btnPesquisarPet;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JTextField cor_pet;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jtl_consultar_dono;
    private javax.swing.JTable jtl_consultar_pet;
    private javax.swing.JFormattedTextField nasc_pet;
    private javax.swing.JTextField nome_pet;
    private javax.swing.JTextField pesquisa_nome_dono;
    private javax.swing.JTextField pesquisa_nome_pet;
    private javax.swing.JTextField raca_pet;
    private javax.swing.JTextField rga_pet;
    private javax.swing.JComboBox<String> sexo_pet;
    // End of variables declaration//GEN-END:variables
}

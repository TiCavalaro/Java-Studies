package br.com.projeto_3.dto;
import java.util.Date;

public class PetDTO {
    private String rga_pet, sexo_pet, cor_pet, nome_pet, raca_pet;
    private Date nasc_vet;
    private int id_pet;

    public String getRga_pet() {
        return rga_pet;
    }

    public void setRga_pet(String rga_pet) {
        this.rga_pet = rga_pet;
    }

    public String getSexo_pet() {
        return sexo_pet;
    }

    public void setSexo_pet(String sexo_pet) {
        this.sexo_pet = sexo_pet;
    }

    public String getCor_pet() {
        return cor_pet;
    }

    public void setCor_pet(String cor_pet) {
        this.cor_pet = cor_pet;
    }

    public String getNome_pet() {
        return nome_pet;
    }

    public void setNome_pet(String nome_pet) {
        this.nome_pet = nome_pet;
    }

    public String getRaca_pet() {
        return raca_pet;
    }

    public void setRaca_pet(String raca_pet) {
        this.raca_pet = raca_pet;
    }

    public Date getNasc_vet() {
        return nasc_vet;
    }

    public void setNasc_vet(Date nasc_vet) {
        this.nasc_vet = nasc_vet;
    }

    public int getId_pet() {
        return id_pet;
    }

    public void setId_pet(int id_pet) {
        this.id_pet = id_pet;
    }
    

}

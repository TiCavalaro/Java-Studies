package br.com.projeto_3.dto;
import java.util.Date;

public class VeterinarioDTO {
    private String nome_vet, cpf_vet, sexo_vet, tel_vet, rua_vet, num_vet;
    private String bairro_vet, cep_vet, cidade_vet, estado_vet, crmv_vet, especialidade_vet;
    private Date nasc_vet;
    private int id_vet;

    public String getNome_vet() {
        return nome_vet;
    }

    public void setNome_vet(String nome_vet) {
        this.nome_vet = nome_vet;
    }

    public String getCpf_vet() {
        return cpf_vet;
    }

    public void setCpf_vet(String cpf_vet) {
        this.cpf_vet = cpf_vet;
    }

    public String getSexo_vet() {
        return sexo_vet;
    }

    public void setSexo_vet(String sexo_vet) {
        this.sexo_vet = sexo_vet;
    }

    public String getTel_vet() {
        return tel_vet;
    }

    public void setTel_vet(String tel_vet) {
        this.tel_vet = tel_vet;
    }

    public String getRua_vet() {
        return rua_vet;
    }

    public void setRua_vet(String rua_vet) {
        this.rua_vet = rua_vet;
    }

    public String getNum_vet() {
        return num_vet;
    }

    public void setNum_vet(String num_vet) {
        this.num_vet = num_vet;
    }

    public String getBairro_vet() {
        return bairro_vet;
    }

    public void setBairro_vet(String bairro_vet) {
        this.bairro_vet = bairro_vet;
    }

    public String getCep_vet() {
        return cep_vet;
    }

    public void setCep_vet(String cep_vet) {
        this.cep_vet = cep_vet;
    }

    public String getCidade_vet() {
        return cidade_vet;
    }

    public void setCidade_vet(String cidade_vet) {
        this.cidade_vet = cidade_vet;
    }

    public String getEstado_vet() {
        return estado_vet;
    }

    public void setEstado_vet(String estado_vet) {
        this.estado_vet = estado_vet;
    }

    public String getCrmv_vet() {
        return crmv_vet;
    }

    public void setCrmv_vet(String crmv_vet) {
        this.crmv_vet = crmv_vet;
    }

    public String getEspecialidade_vet() {
        return especialidade_vet;
    }

    public void setEspecialidade_vet(String especialidade_vet) {
        this.especialidade_vet = especialidade_vet;
    }

    public Date getNasc_vet() {
        return nasc_vet;
    }

    public void setNasc_vet(Date nasc_vet) {
        this.nasc_vet = nasc_vet;
    }

    public int getId_vet() {
        return id_vet;
    }

    public void setId_vet(int id_vet) {
        this.id_vet = id_vet;
    }
    
}

   
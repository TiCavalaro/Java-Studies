package br.com.projeto_3.dto;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DonoDTO {
    private String nome_dono, cpf_dono, sexo_dono, tel_dono, rua_dono; 
    private String num_dono, bairro_dono, cep_dono, cidade_dono, estado_dono;
    private Date nasc_dono;
    private int id_dono;

    public String getNome_dono() {
        return nome_dono;
    }

    public void setNome_dono(String nome_dono) {
        this.nome_dono = nome_dono;
    }

    public String getCpf_dono() {
        return cpf_dono;
    }

    public void setCpf_dono(String cpf_dono) {
        this.cpf_dono = cpf_dono;
    }

    public String getSexo_dono() {
        return sexo_dono;
    }

    public void setSexo_dono(String sexo_dono) {
        this.sexo_dono = sexo_dono;
    }

    public String getTel_dono() {
        return tel_dono;
    }

    public void setTel_dono(String tel_dono) {
        this.tel_dono = tel_dono;
    }

    public String getRua_dono() {
        return rua_dono;
    }

    public void setRua_dono(String rua_dono) {
        this.rua_dono = rua_dono;
    }

    public String getNum_dono() {
        return num_dono;
    }

    public void setNum_dono(String num_dono) {
        this.num_dono = num_dono;
    }

    public String getBairro_dono() {
        return bairro_dono;
    }

    public void setBairro_dono(String bairro_dono) {
        this.bairro_dono = bairro_dono;
    }

    public String getCep_dono() {
        return cep_dono;
    }

    public void setCep_dono(String cep_dono) {
        this.cep_dono = cep_dono;
    }

    public String getCidade_dono() {
        return cidade_dono;
    }

    public void setCidade_dono(String cidade_dono) {
        this.cidade_dono = cidade_dono;
    }

    public String getEstado_dono() {
        return estado_dono;
    }

    public void setEstado_dono(String estado_dono) {
        this.estado_dono = estado_dono;
    }

    public Date getNasc_dono() {
        return nasc_dono;
    }

    public void setNasc_dono(Date nasc_dono) {
        this.nasc_dono = nasc_dono;
    }

    public int getId_dono() {
        return id_dono;
    }

    public void setId_dono(int id_dono) {
        this.id_dono = id_dono;
    }
}
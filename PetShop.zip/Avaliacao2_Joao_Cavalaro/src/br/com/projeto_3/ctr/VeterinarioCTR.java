package br.com.projeto_3.ctr;
import java.sql.ResultSet;
import br.com.projeto_3.dto.VeterinarioDTO;
import br.com.projeto_3.dao.VeterinarioDAO;
import br.com.projeto_3.dao.ConexaoDAO;

public class VeterinarioCTR {
    VeterinarioDAO veterinarioDAO = new VeterinarioDAO();
    
    public VeterinarioCTR(){
    }
    
    public String inserirVeterinario(VeterinarioDTO veterinarioDTO) {
        try {
            if (veterinarioDAO.inserirVeterinario(veterinarioDTO))             
                return "Veterinário cadastrado com sucesso!";
            
            else 
                return "Veterinário não cadastrado!"; 
        }
        catch (Exception e) {  
            System.out.println(e.getMessage());
            
            return "Dados não cadrastados!";
        }
    }
   
    public String alterarVeterinario(VeterinarioDTO veterinarioDTO) {  
        try{    
            if(veterinarioDAO.alterarVeterinario(veterinarioDTO)) 
                return "Veterinário alterado com sucesso!";
            else 
                return "Veterinário não alterado!";
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            
            return"Veterinário não Alterado";
        }
    }
    
    public String excluirVeterinario(VeterinarioDTO veterinarioDTO) {
        try{     
            if(veterinarioDAO.excluirVeterinario(veterinarioDTO)) 
                return "Veterinário excluído com sucesso!";
            else 
                return "Veterinário não excluído!";        
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return "Veterinário não excluído!";
        }
    }
    
    public ResultSet consultarVeterinario(VeterinarioDTO veterinarioDTO, int opcao) {
        ResultSet rs = null;
        
        rs = veterinarioDAO.consultarVeterinario(veterinarioDTO, opcao);
        
        return rs;
    }
    
    
    public void CloseDB() {   
        ConexaoDAO.CloseDB();
    }
    
}

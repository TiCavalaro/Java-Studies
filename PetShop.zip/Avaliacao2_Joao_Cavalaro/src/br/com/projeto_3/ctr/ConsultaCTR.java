package br.com.projeto_3.ctr;
import br.com.projeto_3.dto.VeterinarioDTO;
import br.com.projeto_3.dao.ConexaoDAO;
import br.com.projeto_3.dto.ConsultaDTO;
import br.com.projeto_3.dao.ConsultaDAO;
import javax.swing.JTable;

public class ConsultaCTR {
    ConsultaDAO consultaDAO = new ConsultaDAO();

    public ConsultaCTR(){
    }
    
    public String inserirConsulta(ConsultaDTO consultaDTO, VeterinarioDTO veterinarioDTO, JTable tipo){
        try{
            if(consultaDAO.inserirConsulta(consultaDTO, veterinarioDTO, tipo))
                return "Consulta marcada com sucesso!";
            else
                return "Consulta não marcada!";
            
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            
            return "Consulta não cadastrada!";
        }
    }
    
    public void CloseDB() {
        ConexaoDAO.CloseDB();
    }
    
}

package br.com.projeto_3.ctr;
import java.sql.ResultSet;
import br.com.projeto_3.dao.ConexaoDAO;
import br.com.projeto_3.dao.DonoDAO;
import br.com.projeto_3.dto.DonoDTO;

public class DonoCTR {
    DonoDAO donoDAO = new DonoDAO();
    
    public DonoCTR(){
    }
    
    public String inserirDono(DonoDTO donoDTO) {       
        try {
            if(donoDAO.inserirDono(donoDTO))             
                return "Dono cadastrado com sucesso!";
            else
                return "Dono não cadastrado!";
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return "Dono não cadrastado!";
        }
    }
    
    public String alterarDono(DonoDTO donoDTO){
        try{
            if(donoDAO.alterarDono(donoDTO))
                return "Dono alterado com sucesso!!";
            else
                return "Dono não alterado.";
        }
        catch(Exception e){         
            System.out.println(e.getMessage());
            
            return "Dono não alterado";
        }
    }
    
    public String excluirDono(DonoDTO donoDTO){
        try{
            if(donoDAO.excluirDono(donoDTO))
                return "Dono excluído com sucesso!";
            else
                return "Dono não excluído!";
        }catch (Exception e){
                System.out.println(e.getMessage());

                return "Dono não excluído!";
        }
    }
    
    public ResultSet consultarDono(DonoDTO donoDTO, int opcao) {
        ResultSet rs = null;
        
        rs = donoDAO.consultarDono(donoDTO, opcao);
        
        return rs;
    }
    
    public void CloseDB() {
        ConexaoDAO.CloseDB();
    }
}

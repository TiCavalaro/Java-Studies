package br.com.projeto_3.ctr;
import java.sql.ResultSet;
import br.com.projeto_3.dto.PetDTO;
import br.com.projeto_3.dao.PetDAO;
import br.com.projeto_3.dto.DonoDTO;
import br.com.projeto_3.dao.ConexaoDAO;

public class PetCTR {
    PetDAO petDAO = new PetDAO();
    
    public PetCTR(){
    }
    
    public String inserirPet(PetDTO petDTO, DonoDTO donoDTO) {       
        try {
            if (petDAO.inserirPet(petDTO, donoDTO))             
                return "Pet cadastrado com sucesso!";
            else
                return "Pet não cadastrado!";
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return "Pet não cadrastado!";
        }
    }
    
    public String alterarPet(PetDTO petDTO, DonoDTO donoDTO){
        try{
            if(petDAO.alterarPet(petDTO, donoDTO))
                return "Pet alterado com sucesso!!";
            else
                return "Pet não alterado.";
        }
        catch(Exception e){         
            System.out.println(e.getMessage());
            
            return "Pet não alterado";
        }
    }
    public String excluirPet(PetDTO petDTO){
        try{
            if(petDAO.excluirPet(petDTO))
                return "Pet excluído com sucesso!";
            else
                return "Pet não excluído!";
        }catch (Exception e){
                System.out.println(e.getMessage());

                return "Pet não excluído!";
        }
    }
    
    public ResultSet consultarPet(PetDTO petDTO, int opcao) {
        ResultSet rs = null;
        
        rs = petDAO.consultarPet(petDTO, opcao);
        
        return rs;
    }
    
    public void CloseDB() {
        ConexaoDAO.CloseDB();
    }
}

package br.com.projeto_3.dao;
import java.sql.*;
import br.com.projeto_3.dto.ConsultaDTO;
import br.com.projeto_3.dto.VeterinarioDTO;

import javax.swing.JTable;

public class ConsultaDAO {
     
    public ConsultaDAO(){
    }
    
    
    
    private ResultSet rs = null;
  
    Statement stmt = null;   
    Statement stmt1 = null;
    
    public boolean inserirConsulta(ConsultaDTO consultaDTO, VeterinarioDTO veterinarioDTO, JTable tipo){
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            stmt1 = ConexaoDAO.con.createStatement();
            
            String comando1 = "Insert into consulta(tipo_consulta, valor_consulta"
                    + "id_vet) values ( "
                    + "'" + consultaDTO.getTipo_consulta() + "', "
                    + consultaDTO.getValor_consulta() + "', "
                    + veterinarioDTO.getId_vet() + ") ";
                    
            stmt.execute(comando1.toUpperCase(), Statement.RETURN_GENERATED_KEYS);
            
            rs = stmt.getGeneratedKeys();
            
            rs.next();
            
            for (int cont = 0; cont < tipo.getRowCount(); cont++) {
                String comando2 = "Insert into consulta_pet (id_consulta, id_vet, "
                        + "val_consulta, qtd_consulta) values ( "
                        + rs.getInt("id_consulta") + ", "
                        + tipo.getValueAt(cont, 0) + ", "
                        + tipo.getValueAt(cont, 2) + ", "
                        + tipo.getValueAt(cont, 3) + "); ";
                
                stmt1.execute(comando2);
            }
            ConexaoDAO.con.commit();
            
            stmt.close();
            stmt1.close();
            rs.close();
            return true;
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            
            return false;
        }
        finally{
            ConexaoDAO.CloseDB();
        }
        
    }
}
package br.com.projeto_3.dao;
import java.sql.*;
import br.com.projeto_3.dto.DonoDTO;
import java.text.SimpleDateFormat;

public class DonoDAO {
     public DonoDAO(){
    }
    
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    private ResultSet rs = null;
  
    private Statement stmt = null;   
    
    public boolean inserirDono(DonoDTO donoDTO){
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into dono(nome_dono, cpf_dono, sexo_dono, "
                    + "nasc_dono, tel_dono, rua_dono, num_dono, bairro_dono, "
                    + "cep_dono, cidade_dono, estado_dono) values ( "
                    + "'" + donoDTO.getNome_dono()+ "', "
                    + "'" + donoDTO.getCpf_dono()+ "', "
                    + "'" + donoDTO.getSexo_dono()+ "', "
                    + "to_date('" + data_format.format(donoDTO.getNasc_dono()) + "',' dd/mm/yyyy'), "
                    + "'" + donoDTO.getTel_dono()+ "', "
                    + "'" + donoDTO.getRua_dono()+ "', "
                    + "" + donoDTO.getNum_dono()+ ", "
                    + "'" + donoDTO.getBairro_dono()+ "', "
                    + "'" + donoDTO.getCep_dono()+ "', "
                    + "'" + donoDTO.getCidade_dono()+ "', "
                    + "'" + donoDTO.getEstado_dono()+ "') ";
            System.out.println(comando);
            
            stmt.execute(comando.toUpperCase());
            
            ConexaoDAO.con.commit();
            
            stmt.close();
            
            return true;
        }
        catch(SQLException e) {
            System.out.println(e.getMessage());
            
            return false;  
        }
        finally { 
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarDono(DonoDTO donoDTO) {
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Update dono set "
                    + "nome_dono= '" + donoDTO.getNome_dono()+ "',"
                    + "cpf_dono = '" + donoDTO.getCpf_dono()+ "',"
                    + "sexo_dono = '" + donoDTO.getSexo_dono()+ "',"
                    + "nasc_dono = to_date('" + data_format.format(donoDTO.getNasc_dono()) + "','dd/mm/yyyy'), "
                    + "tel_dono = '" + donoDTO.getTel_dono()+ "',"
                    + "rua_dono = '" + donoDTO.getRua_dono()+ "',"
                    + "num_dono = " + donoDTO.getNum_dono()+ ","
                    + "bairro_dono = '" + donoDTO.getBairro_dono()+ "',"
                    + "cep_dono = '" + donoDTO.getCep_dono()+ "',"
                    + "cidade_dono = '" + donoDTO.getCidade_dono()+ "',"
                    + "estado_dono = '" + donoDTO.getEstado_dono()+ "'"
                    + "where id_dono = " + donoDTO.getId_dono();
            System.out.println(comando);
                    
            stmt.execute(comando.toUpperCase());
           
            ConexaoDAO.con.commit();
           
            stmt.close();
            
            return true; 
        }catch(Exception e){ 
            System.out.println(e.getMessage());
            
            return false;
        }finally {
            ConexaoDAO.CloseDB();
        }
     
    }
   
    public boolean excluirDono(DonoDTO donoDTO){
           try{
               ConexaoDAO.ConectDB();

               stmt = ConexaoDAO.con.createStatement();
               
               String comando = "Delete from dono where id_dono = " + donoDTO.getId_dono();

                stmt.execute(comando.toUpperCase());

               ConexaoDAO.con.commit();

               stmt.close();

               return true;
           }
           catch(SQLException e) {
               System.out.println(e.getMessage());
               
               return false;
           }
           finally {
               ConexaoDAO.CloseDB();
           }
   }
    
   public ResultSet consultarDono(DonoDTO donoDTO, int opcao) {
        try {
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "";
            switch (opcao){
                case 1:
                    comando = "Select d.id_dono, d.nome_dono "+
                              "from dono d "+
                              "where d.nome_dono like '" + donoDTO.getNome_dono()+ "%' " +
                              "order by d.nome_dono";    
                break;
                case 2:
                    comando = "Select d.* " +
                               "from dono d " +
                               "where d.id_dono = " + donoDTO.getId_dono();
                break;         
            }
            System.out.println(comando);
            rs = stmt.executeQuery(comando.toUpperCase());
            
            return rs;
        } 
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return rs;
        }
    }
}
package br.com.projeto_3.dao;
import br.com.projeto_3.dto.DonoDTO;
import java.sql.*;
import br.com.projeto_3.dto.VeterinarioDTO;
import java.text.SimpleDateFormat;

public class VeterinarioDAO {
    public VeterinarioDAO(){
    }
    
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    private ResultSet rs = null;
  
    private Statement stmt = null;   
    
    public boolean inserirVeterinario(VeterinarioDTO veterinarioDTO){
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into veterinario(nome_vet, cpf_vet, sexo_vet"
                    + "nasc_vet, tel_vet, rua_vet, num_vet, bairro_vet"
                    + "cep_vet, cidade_vet, estado_vet, crmv, especialidade) values ( "
                    + "'" + veterinarioDTO.getNome_vet()+ "', "
                    + "'" + veterinarioDTO.getCpf_vet()+ "', "
                    + "'" + veterinarioDTO.getSexo_vet()+ "', "
                    + "to_date('" + data_format.format(veterinarioDTO.getNasc_vet()) + "',' dd/mm/yyyy'))"
                    + "'" + veterinarioDTO.getTel_vet()+ "', "
                    + "'" + veterinarioDTO.getRua_vet()+ "', "
                    + "'" + veterinarioDTO.getNum_vet()+ "', "
                    + "'" + veterinarioDTO.getBairro_vet()+ "', "
                    + "'" + veterinarioDTO.getCep_vet()+ "', "
                    + "'" + veterinarioDTO.getCidade_vet()+ "', "
                    + "'" + veterinarioDTO.getEstado_vet()+ "', "
                    + "'" + veterinarioDTO.getCrmv_vet()+ "', "
                    + "'" + veterinarioDTO.getEspecialidade_vet()+ "', ";
            
            stmt.execute(comando.toUpperCase());
            
            ConexaoDAO.con.commit();
            
            stmt.close();
            
            return true;
        }
        catch(SQLException e) {
            System.out.println(e.getMessage());
            
            return false;  
        }
        finally { 
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarVeterinario(VeterinarioDTO veterinarioDTO) {
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Update veterinario set "
                    + "nome_veterinario= '" + veterinarioDTO.getNome_vet()+ "',"
                    + "cpf_vet = '" + veterinarioDTO.getCpf_vet()+ "',"
                    + "sexo_vet'" + veterinarioDTO.getSexo_vet()+ "',"
                    + "nasc_vet = to_date('" + data_format.format(veterinarioDTO.getNasc_vet()) + "',' dd/mm/yyyy)"
                    + "tel_vet'" + veterinarioDTO.getTel_vet()+ "',"
                    + "rua_vet'" + veterinarioDTO.getRua_vet()+ "',"
                    + "num_vet = '" + veterinarioDTO.getNum_vet()+ "',"
                    + "bairro_vet'" + veterinarioDTO.getBairro_vet()+ "',"
                    + "cep_dono = '" + veterinarioDTO.getCep_vet()+ "',"
                    + "cidade_vet'" + veterinarioDTO.getCidade_vet()+ "',"
                    + "estado_vet = '" + veterinarioDTO.getEstado_vet()+ "',"
                    + "cidade_vet'" + veterinarioDTO.getCidade_vet()+ "',"
                    + "estado_vet = '" + veterinarioDTO.getEstado_vet()+ "',"
                    + "crmv_vet'" + veterinarioDTO.getCrmv_vet()+ "',"
                    + "especialidade_vet = '" + veterinarioDTO.getEspecialidade_vet()+ "',"
                    + "where id_vet = " + veterinarioDTO.getId_vet();
                    
            stmt.execute(comando.toUpperCase());
           
            ConexaoDAO.con.commit();
           
            stmt.close();
            
            return true; 
        }catch(Exception e){ 
            System.out.println(e.getMessage());
            
            return false;
        }finally {
            ConexaoDAO.CloseDB();
        }
     
    }
   
    public boolean excluirVeterinario(VeterinarioDTO veterinarioDTO){
           try{
               ConexaoDAO.ConectDB();

               stmt = ConexaoDAO.con.createStatement();
               
               String comando = "Delete from veterinario where id_vet = " + veterinarioDTO.getId_vet();

                stmt.execute(comando.toUpperCase());

               ConexaoDAO.con.commit();

               stmt.close();

               return true;
           }
           catch(SQLException e) {
               System.out.println(e.getMessage());
               
               return false;
           }
           finally {
               ConexaoDAO.CloseDB();
           }
   }
    
   public ResultSet consultarVeterinario(VeterinarioDTO veterinarioDTO, int opcao) {
        try {
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "";
            switch (opcao){
               case 1:
                    comando = "Select v.* "+
                              "from veterinario v "+
                              "where nome_vet like '" + veterinarioDTO.getNome_vet()+ "%' " +
                              "order by v.nome_vet";    
                break;
                case 2:
                    comando = "Select v.* "+
                              "from veterinario v " +
                              "where v.id_veterinario = " + veterinarioDTO.getId_vet();
                break;
                case 3:
                    comando = "Select v.id_veterinario, v.veterinario "+
                              "from veterinario v ";
                break;      
            }
            rs = stmt.executeQuery(comando.toUpperCase());
            
            return rs;
        } 
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return rs;
        }
    }
}
    

package br.com.projeto_3.dao;
import java.sql.*;
import br.com.projeto_3.dto.PetDTO;
import br.com.projeto_3.dto.DonoDTO;
import java.text.SimpleDateFormat;

public class PetDAO {
    
    public PetDAO(){
    }
    
    SimpleDateFormat data_format = new SimpleDateFormat("dd/mm/yyyy");
    
    private ResultSet rs = null;
  
    private Statement stmt = null;   
    
    public boolean inserirPet(PetDTO petDTO, DonoDTO donoDTO){
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            String comando = "Insert into pet(nome_pet, rga_pet, sexo_pet, "
                    + "nasc_pet, raca_pet, cor_pet, id_dono) values ( "
                    + "'" + petDTO.getNome_pet() + "', "
                    + "'" + petDTO.getRga_pet() + "', "
                    + "'" + petDTO.getSexo_pet() + "', "
                    + "to_date('" + data_format.format(petDTO.getNasc_vet()) + "','dd/mm/yyyy'), "
                    + "'" + petDTO.getRaca_pet() + "', "
                    + "'" + petDTO.getCor_pet() + "', "
                    + donoDTO.getId_dono() + ") ";
            System.out.println(comando);
                    
             stmt.execute(comando.toUpperCase());
            
            ConexaoDAO.con.commit();
            
            stmt.close();
            
            return true;
        }
        catch(SQLException e) {
            
            System.out.println(e.getMessage());
            return false;  
        }
        finally { 
            ConexaoDAO.CloseDB();
        }
    }
    
    public boolean alterarPet(PetDTO petDTO, DonoDTO donoDTO) {
        try{
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "Update pet set "
                    + "nome_pet= '" + petDTO.getNome_pet() + "',"
                    + "rga_pet = '" + petDTO.getRga_pet() + "',"
                    + "sexo_pet = '" + petDTO.getSexo_pet() + "',"
                    + "nasc_pet = to_date('" + data_format.format(petDTO.getNasc_vet()) + "',' dd/mm/yyyy),"
                    + "raca_pet = '" + petDTO.getRaca_pet() + "',"
                    + "cor_pet' = " + petDTO.getCor_pet() + "',"
                    + "id_dono = " + donoDTO.getId_dono() + " "
                    + "where id_pet = " + petDTO.getId_pet();
                    
            stmt.execute(comando.toUpperCase());
           
            ConexaoDAO.con.commit();
           
            stmt.close();
            
            return true; 
        }catch(Exception e){ 
            System.out.println(e.getMessage());
            
            return false;
        }finally {
            ConexaoDAO.CloseDB();
        }
     
    }
   
    public boolean excluirPet(PetDTO petDTO){
           try{
               ConexaoDAO.ConectDB();

               stmt = ConexaoDAO.con.createStatement();
                String comando = "Delete from pet where id_pet = "
                        + petDTO.getId_pet();

                stmt.execute(comando.toUpperCase());

               ConexaoDAO.con.commit();

               stmt.close();

               return true;
           }
           catch(SQLException e) {
               System.out.println(e.getMessage());
               return false;

           }
           finally {
               ConexaoDAO.CloseDB();
           }
   }
   public ResultSet consultarPet(PetDTO petDTO, int opcao) {
        try {
            ConexaoDAO.ConectDB();
            
            stmt = ConexaoDAO.con.createStatement();
            
            String comando = "";
            switch (opcao){
                case 1:
                    comando = "Select p.id_pet, p.nome_pet "+
                              "from pet p "+
                              "where p.nome_pet like '" + petDTO.getNome_pet()+ "%' " +
                              "order by p.nome_pet";    
                break;
                case 2:
                    comando = "Select p.*, d.nome_dono, d.id_dono " +
                               "from pet p, dono d " +
                               "where p.id_dono = d.id_dono and " + 
                               "p.id_pet = " + petDTO.getId_pet();
                break;         
            }
            rs = stmt.executeQuery(comando.toUpperCase());
            
            return rs;
        } 
        catch (Exception e) {
            System.out.println(e.getMessage());
            
            return rs;
        }
    }
}
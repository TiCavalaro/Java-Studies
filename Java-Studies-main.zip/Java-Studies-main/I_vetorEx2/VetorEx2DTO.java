/*
Faça um programa que construa um vetor com 6 notas de 0 a 10.
Depois mostre as notas digitadas. Mostre também a média das notas.
 */
package I_vetorEx2;

public class VetorEx2DTO {
    private int[] vetor = new int[5];

    public int[] getVetor() {
        return vetor;
    }

    public void setVetor(int[] vetor) {
        this.vetor = vetor;
    }
    
}

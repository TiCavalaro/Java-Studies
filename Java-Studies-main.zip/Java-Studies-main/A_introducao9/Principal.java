/*
FAÇA UM PROGRAMA QUE CALCULE A IDADE DE UMA PESSOA A PARTIR DO ANO DE NASCIMENTO.
PARA ISSO CRIE UM MÉTODO QUE FAÇA O CALCULO, SEM PASSAGEM DE PARÂMETRO E SEM RETORNO.
 */
package A_introducao9;

import javax.swing.JOptionPane;


public class Principal {
    public static void main(String[] args) {
        CalculoIdade calculoIdade = new CalculoIdade();
               
        calculoIdade.calcularIdade();
        
    }
    
}

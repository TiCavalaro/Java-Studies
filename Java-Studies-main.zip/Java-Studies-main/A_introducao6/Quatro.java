/*
 FACA UM ALGORITMO QUE RECEBE TRES NUMEROS OBRIGATORIAMENTE EM ORDEM CRESCENTE 
 E UM QUARTO NUMERO QUALQUER. AO FINAL O ALGORITMO DEVE MOSTRAR OS QUATRO 
 NUMEROS EM ORDEM DECRESCENTE. OS NUMEROS DEVEM SER DO TIPO INTEIRO.
 */
package A_introducao6;


public class Quatro {
    private int n1, n2, n3, n4;
    
    public void mostrarNumero(int n1, int n2, int n3, int n4){
        this.n1 = n1;
        this.n2 = n2;
        this.n3 = n3;
        this.n4 = n4;
        
        
        
    }
    
}
